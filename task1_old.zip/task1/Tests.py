#import numpy as np
#print(np.linalg.det(np.array(data.sle0.A)))
# https://ru.stackoverflow.com/questions/1150851/метод-гаусса-на-python-3
