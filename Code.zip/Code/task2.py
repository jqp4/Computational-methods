from SLE import SLE
from Gauss import gauss
from DataSet import DataSet
from linalg import det, inverse, print_matrix, cond, norm





def main():
    print("\n" * 10)
    dataset = DataSet()
    sle = dataset.sle[0]





    




main() 